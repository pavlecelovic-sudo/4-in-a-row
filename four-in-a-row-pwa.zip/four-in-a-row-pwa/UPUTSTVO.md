# 4 IN A ROW — PWA paket za iPhone Home Screen

Igra je ista igra. Dodata je samo PWA infrastruktura (instalacija na Home Screen, offline rad, ikone).
Ništa nije objavljeno niti postavljeno na hosting — to radite vi, kada odlučite.

## Šta je u paketu

```
four-in-a-row-pwa/
├─ site/                    ← OVAJ folder se otprema na hosting
│  ├─ index.html            igra (vaš fajl + dva dodata PWA bloka)
│  ├─ manifest.json         ime, ikone, standalone prikaz, boje
│  ├─ service-worker.js     offline keš + ažuriranje
│  ├─ _headers              pravila keširanja (Cloudflare Pages i Netlify)
│  ├─ icons/                apple-touch-icon (180), 192, 512, maskable 512, icon-source.svg
│  └─ splash/               13 launch ekrana za iPhone (tamna pozadina + ikona)
└─ UPUTSTVO.md              ovaj fajl
```

## Šta je tačno promenjeno u igri

Original `four-in-a-row_1.html` je preimenovan u `index.html` (tako hosting očekuje) i u njega su dodata **samo dva bloka**:

1. **U `<head>`** (označen `<!-- PWA (added) … <!-- /PWA -->`): link na manifest, `apple-mobile-web-app-*` meta tagovi,
   `apple-touch-icon`, launch ekrani i jedno usko CSS pravilo (vidi dole).
2. **Pred `</body>`**: mala skripta koja registruje service worker (samo preko HTTPS ili localhost) i, samo u instaliranoj
   aplikaciji, blokira nehotično zumiranje prstima (pinch). Dodir i skrolovanje ostaju netaknuti.

Ako se ta dva bloka obrišu, fajl je **bajt-po-bajt identičan** vašem originalu (proveren SHA-256).
Dizajn, raspored, animacije, pravila, bodovanje i čuvanje rezultata (`fiar.v1.*` u localStorage) nisu dirani.

**Jedini vizuelni dodatak:** u instaliranoj aplikaciji, i samo u svetloj temi, iza statusne linije telefona stoji tamna
traka visine tačno koliko je status bar. Razlog: iOS tamo uvek crta *belo* vreme i bateriju, koji bi na svetloj stranici
bili nevidljivi. U tamnoj temi, u Safari-ju i na uređajima bez status bara trake nema. Ako je ne želite, obrišite
`<style>` blok unutar PWA bloka u `<head>`.

---

## 1. HTTPS hosting

**Zašto HTML kod nije dovoljan.** HTTPS ne dolazi iz HTML-a: to je sertifikat koji server prikazuje pregledaču. Nju
obezbeđuje hosting (izdaje i automatski obnavlja sertifikat za vašu adresu). iPhone Safari bez HTTPS-a neće registrovati
service worker, pa nema ni offline rada ni pravilne instalacije. Zato je potreban hosting, a ne izmena koda.

### Preporuka: Cloudflare Pages (besplatno, bez komandne linije)

1. Napravite besplatan nalog na cloudflare.com.
2. Dashboard → **Workers & Pages** → **Create application** → **Pages** → otpremanje prevlačenjem
   (*Direct Upload / Drag and drop your files*). Tekst u interfejsu se ponekad menja, ali opcija postoji.
3. Dajte ime projektu (npr. `cetiri-u-nizu`) i prevucite folder **`site`** (ne ZIP celog paketa).
4. **Deploy.** Dobijate adresu `https://cetiri-u-nizu.pages.dev` sa već uključenim HTTPS-om, bez ikakvog podešavanja.

Alternative:
- **Netlify** (`app.netlify.com/drop`): prevučete folder `site`. Bez naloga je sajt privremen i istekne ako ga ne
  preuzmete (*claim*), pa se registrujte besplatno da ga zadržite. HTTPS je automatski.
- **GitHub Pages**: besplatan HTTPS na `github.io`, ali na besplatnom planu repozitorijum mora biti **javan**, pa bi
  kod igre bio javno vidljiv.

Napomena: svaka od ovih adresa je javna za svakoga ko zna link. Dok ništa ne otpremite, ništa nije javno.

---

## 2. Instalacija na iPhone

1. U **Safari-ju** otvorite HTTPS adresu igre (ne u pregledaču unutar neke druge aplikacije).
2. Sačekajte da se igra potpuno učita. Prvo otvaranje mora biti sa internetom jer se tada puni offline keš.
3. Dodirnite **Share** (kvadrat sa strelicom) → **Add to Home Screen** (možda treba skrolovati listu) →
   ime je već predloženo „4 in a Row” → **Add**.
4. Pokrećite igru sa ikone na Home Screen-u. Otvara se preko celog ekrana, bez Safari trake.
5. Provera offline rada: uključite **Airplane Mode**, potpuno zatvorite aplikaciju (prevlačenje nagore) i otvorite je ponovo.

**Važno o sačuvanim podacima.** Aplikacija sa Home Screen-a ima **odvojen prostor za čuvanje** od Safari-ja. Podešavanja,
statistika i FOUR Pay novčanik odigrani u Safari-ju **ne prelaze** u instaliranu aplikaciju. Ona počinje „čista”.
Brisanjem ikone briše se i sve što je u njoj sačuvano.

---

## 3. Ažuriranje (da ne ostanete na starim fajlovima)

1. Izmenite fajlove (npr. `index.html`).
2. U `service-worker.js` povećajte broj verzije: `var VERSION = '1.0.0';` → `'1.0.1'`.
3. Ponovo otpremite folder `site` (na Cloudflare Pages: novi *deployment* u istom projektu).
4. Na iPhone-u **potpuno zatvorite aplikaciju** (App Switcher, prevlačenje nagore) i otvorite je sa internetom.

Kako je to rešeno: pri svakom pokretanju sa internetom igra se traži sa servera (provera je jeftina ako se ništa nije
promenilo), pa uvek dobijate najnoviju verziju. Ako je mreža spora (više od 3 s) ili je nema, koristi se sačuvana kopija.
Stari keš se briše sam. Partija koja je u toku se nikada ne prekida: otvorena igra ostaje na verziji sa kojom je
pokrenuta do sledećeg pokretanja. Aplikacija koja stoji u pozadini može da drži staru verziju u memoriji sve dok se ne zatvori.

---

## 4. Rezultati testiranja

Testirano automatizovano u Chromium 153 (emulacija iPhone ekrana, dodira i safe-area vrednosti).

| Provera | Rezultat |
|---|---|
| Manifest se parsira bez grešaka; ime, `start_url`, `scope`, `standalone`, boje `#070B1A` | prolazi |
| Sve ikone postoje i imaju tačno deklarisane dimenzije; `apple-touch-icon` 180×180 bez providnosti | prolazi |
| Svih 13 launch ekrana postoje i odgovaraju deklarisanim dimenzijama | prolazi |
| Chromium provera instalabilnosti (`getInstallabilityErrors`) | 0 grešaka |
| Service worker se registruje, aktivira i kontroliše stranicu; keš ima stranicu, manifest i ikone | prolazi |
| **Offline**: ponovno učitavanje, `/index.html`, `/?source=pwa`, nepoznata adresa; fontovi i slike soba rade; igra reaguje na dodir | prolazi |
| Igra ne šalje nijedan mrežni zahtev osim sopstvenih fajlova | prolazi |
| **Ažuriranje**: nova verzija se prikazuje pri prvom sledećem pokretanju; stari keš se briše; i zaostali keš se čisti sam; offline koristi novu verziju | prolazi |
| Spora mreža (7 s): igra se otvara iz sačuvane kopije za ~3 s | prolazi |
| Hosting koji preusmerava `/index.html` → `/` (Netlify/Cloudflare): keš je ispravan, offline radi | prolazi |
| Otvaranje kao običan fajl (`file://`): radi kao ranije, bez service workera i bez grešaka | prolazi |
| **Igra identična originalu**: isti skriptovani tok (meni, podešavanja, profili, FOUR Pay, prodavnica, partija do pobede, igra protiv računara; isti seed i sat) na originalu i na novoj verziji | stanje igre, sačuvani podaci i DOM identični; **8/8 screenshot-ova identično do piksela** |
| Bajt-po-bajt: `index.html` bez dva PWA bloka = vaš originalni fajl | identično |
| iPhone raspored: 16 Pro Max, 15 Pro, SE; tamna i svetla tema; 8 ekrana (meni, podešavanja, profili, FOUR Pay, prodavnica, podešavanje partije, šampionat, igra) | ništa ispod statusne linije, bez horizontalnog skrola, raspored isti kao u originalu |
| Svetla tema: traka iza statusne linije se pojavljuje samo kada postoji inset, ne hvata dodire | prolazi |

### Šta nije moglo biti testirano

- **Stvarni iPhone i WebKit.** U okruženju za testiranje nije bio dostupan WebKit niti uređaj. Zato nije proveren sam tok
  *Add to Home Screen*, izgled launch ekrana, da `@media (display-mode: standalone)` na iOS-u aktivira traku u svetloj
  temi, niti da blokada pinch-zumiranja deluje. Sve to se proverava za 5 minuta na telefonu (koraci iz odeljka 2, plus:
  svetla tema → proverite da se vreme i baterija vide; pokušajte da zumirate prstima).
- Service worker je pisan prema standardu koji Safari podržava (uključujući izbegavanje poznatog problema sa
  preusmerenim odgovorima), ali iOS Safari je jedini pravi dokaz.

### Postojeće osobine originalne igre (nisu uvedene PWA slojem; nisu menjane jer ste zabranili izmene rasporeda)

- **iPhone u landscape (horizontalno):** meni i većina ekrana nemaju bočni safe-area razmak, pa se levi rub dugmadi može
  približiti Dynamic Island-u. Ekran same partije je ispravno rešen. Isto je i u originalu i u Safari-ju. U portretu
  (uobičajeno) nema problema. Popravka je nekoliko linija CSS-a ako je želite.
- **Ekran „Player profiles”:** poslednje dugme na kraju skrola završava 6 px u zoni home indikatora. Ne smeta u upotrebi.
- **Tekst politike privatnosti** u igri kaže da igra ne koristi internet dok se igra, što i dalje važi. Service worker samo
  čuva kopiju fajlova same igre na uređaju. Ako želite, možete dodati jednu rečenicu o tome; tekst nisam menjao.
